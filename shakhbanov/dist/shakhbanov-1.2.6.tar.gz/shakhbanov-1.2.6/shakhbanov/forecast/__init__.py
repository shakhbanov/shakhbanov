# shakhbanov/forecast/__init__.py

from .forecast import BurgerKing

__all__ = ['BurgerKing']
