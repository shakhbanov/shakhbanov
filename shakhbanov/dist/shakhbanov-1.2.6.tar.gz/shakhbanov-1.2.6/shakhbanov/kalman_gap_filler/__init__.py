# shakhbanov/kalman_gap_filler/__init__.py

from .kalman_gap_filler import KalmanGapFiller

__all__ = ['KalmanGapFiller']