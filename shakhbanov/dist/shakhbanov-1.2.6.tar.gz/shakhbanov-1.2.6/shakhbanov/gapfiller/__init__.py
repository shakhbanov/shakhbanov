# shakhbanov/gapfiller/__init__.py

from .gapfiller import NaturalGapFiller

__all__ = ['NaturalGapFiller']